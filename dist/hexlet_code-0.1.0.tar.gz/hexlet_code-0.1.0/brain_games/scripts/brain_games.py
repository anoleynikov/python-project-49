#!/usr/bin/env python3
import sys 
sys.path.append('/home/anton9760/python-projects/python-project-49/brain_games')
import cli
    
    
cli.welcome_user()

